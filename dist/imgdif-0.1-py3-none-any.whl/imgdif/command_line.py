import imgdif 

def main():
    print(imgdif.app())
